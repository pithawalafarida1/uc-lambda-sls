pip install -r requirements.txt
npm install
npm run deploy